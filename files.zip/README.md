# Verta Delivery Service — Railway realtime rewrite

Firebase is gone. Realtime sync across every open browser/tab now runs
through a single Node.js service on Railway: **Express + Socket.io +
PostgreSQL**.

## Architecture

```
Browser tab A ─┐
Browser tab B ─┼── wss:// (Socket.io) ──► Railway service ──► Postgres
Browser tab C ─┘        ▲   (Express serves the static      (Railway
                         │    frontend on the same port)      Postgres
                    HTTP GET /api/state                       plugin)
                    (one-time initial load)
```

- **One Railway service** runs `server/server.js`. It does two jobs on the
  same port (Railway only exposes one public port per service):
  1. Serves `public/index.html` as static files.
  2. Runs Socket.io for realtime updates.
- **One Railway Postgres plugin**, attached to that service, persists
  orders and expenses. Railway injects `DATABASE_URL` into the service
  automatically when you attach it — no manual config.
- Every browser tab connects to the *same* Socket.io room (`shared-state`)
  because orders/expenses are shared data across all senders and delivery
  agents, not private per user. When any tab creates an order, accepts one,
  changes its status, or adds/deletes an expense, the server persists it to
  Postgres and broadcasts the change to every connected tab — including the
  one that made the change, so there's a single code path for "apply this
  update to the UI."

## Deploying to Railway

1. Push this project to a GitHub repo.
2. In Railway: **New Project → Deploy from GitHub repo**, pick this repo.
3. **Add a Postgres plugin** to the project (`New → Database → PostgreSQL`).
   Railway automatically sets `DATABASE_URL` on your service — you don't
   need to copy/paste it.
4. On your service, open **Variables** and set:
   - `DELIVERY_PASSWORD` — the delivery-agent login password
   - `DELETE_PASSWORD` — the password required for bulk/expense deletes
   - (`PORT` and `DATABASE_URL` are set automatically by Railway — leave
     them alone)
5. Deploy. On first boot, `server.js` runs `schema.sql` automatically to
   create the `orders` and `expenses` tables if they don't exist yet.
6. Open the Railway-provided URL — that's the whole app, frontend and all.

## Running locally

```bash
cd server
cp .env.example .env
# edit .env: point DATABASE_URL at a local or Railway Postgres instance,
# set DELIVERY_PASSWORD / DELETE_PASSWORD
npm install
npm start
```

Then open `http://localhost:3000`.

## What changed from the Firebase version

- Removed both Firebase SDK `<script>` tags and every `firebase.*` /
  `database.ref(...)` call, including the leftover duplicate block at the
  bottom of the original file that redeclared `firebaseConfig` and attached
  a second, conflicting set of form listeners.
- Removed all `localStorage` persistence — Postgres is now the single
  source of truth, reachable by every device.
- `loadOrders()` / `saveOrders()` / `loadExpenses()` / `saveExpenses()`
  are replaced by:
  - `GET /api/state` — one-time fetch on page load.
  - `socket.emit('order:create' | 'order:update' | 'order:accept' |
    'order:delete-bulk' | 'expense:create' | 'expense:delete', ...)` for
    every mutation, with an ack callback so the UI can show an error if the
    server rejects it (e.g. wrong delete password).
  - `socket.on('order:created' | 'order:updated' | 'order:deleted' |
    'expense:created' | 'expense:deleted', ...)` to receive updates from
    any tab (including your own) and re-render.
- Password checks (`login-delivery-btn`, bulk delete, expense delete) moved
  server-side (`server/server.js`, checked against env vars) instead of
  comparing against a hardcoded string in client JS.
- Added a small connection-status pill (bottom-right) so users can tell if
  they've lost their live connection and are seeing stale data.
- Added a generic `debounce()` helper in the frontend. Nothing in this app
  currently saves on every keystroke — every save is a discrete action
  (submit a form, click Accept/Mark Delivered) — so nothing calls it yet,
  but it's there if you add a live-typing field (e.g. draft notes) later:
  wrap the emit in `debounce(() => socket.emit(...), 400)`.

## Note on the "per-user" requirement

If you actually want each logged-in user's *own* devices to sync privately
(separate from other users' data), that needs real user accounts. Today
this app only has two shared passwords (sender side has no login at all;
delivery side has one shared password for all agents), so there's no
concept of "this order belongs to user X." Add authentication (e.g.
JWT or session cookies) and I can switch the Socket.io room strategy from
the current single shared room to `socket.join(userId)` /
`io.to(userId).emit(...)` — the rest of the architecture stays the same.
