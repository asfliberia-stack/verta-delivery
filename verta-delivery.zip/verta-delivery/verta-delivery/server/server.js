// server.js — Express + Socket.io backend for Railway.
// Single container: serves the static frontend AND the realtime API.
require('dotenv').config();
const path = require('path');
const express = require('express');
const http = require('http');
const cors = require('cors');
const { Server } = require('socket.io');
const db = require('./db');

const PORT = process.env.PORT || 3000;
const DELIVERY_PASSWORD = process.env.DELIVERY_PASSWORD || 'change-me';
const DELETE_PASSWORD = process.env.DELETE_PASSWORD || 'change-me';

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

const server = http.createServer(app);

// Socket.io on the same HTTP server/port — Railway only exposes one port
// per service, so frontend and websocket traffic share it. The frontend
// connects with `io()` (no URL) which resolves to same-origin automatically.
const io = new Server(server, {
  cors: { origin: '*' }, // tighten to your real domain once you have one
});

// All connected clients share one room ('shared-state') because this app's
// data (orders/expenses) is shared across every sender + delivery agent,
// not scoped to a single user's devices. If you later add real per-user
// accounts, swap this for `socket.join(userId)` on auth and broadcast with
// `io.to(userId).emit(...)` instead of `io.emit(...)`.
const ROOM = 'shared-state';

io.on('connection', (socket) => {
  socket.join(ROOM);
  console.log(`[socket] client connected: ${socket.id} (${io.engine.clientsCount} online)`);

  socket.on('disconnect', () => {
    console.log(`[socket] client disconnected: ${socket.id}`);
  });

  // ---- Orders -------------------------------------------------------

  socket.on('order:create', async (payload, ack) => {
    try {
      const order = await db.createOrder(payload);
      io.to(ROOM).emit('order:created', order);
      ack && ack({ ok: true, order });
    } catch (err) {
      console.error('order:create failed', err);
      ack && ack({ ok: false, error: 'Failed to create order' });
    }
  });

  socket.on('order:update', async ({ id, fields }, ack) => {
    try {
      const order = await db.updateOrder(id, fields);
      io.to(ROOM).emit('order:updated', order);
      ack && ack({ ok: true, order });
    } catch (err) {
      console.error('order:update failed', err);
      ack && ack({ ok: false, error: 'Failed to update order' });
    }
  });

  socket.on('order:accept', async ({ id, amount, acceptedBy }, ack) => {
    try {
      const order = await db.updateOrder(id, {
        amount,
        acceptedBy,
        status: 'accepted',
        acceptedAt: new Date().toISOString(),
      });
      io.to(ROOM).emit('order:updated', order);
      ack && ack({ ok: true, order });
    } catch (err) {
      console.error('order:accept failed', err);
      ack && ack({ ok: false, error: 'Failed to accept order' });
    }
  });

  socket.on('order:delete-bulk', async ({ ids, password }, ack) => {
    if (password !== DELETE_PASSWORD) {
      ack && ack({ ok: false, error: 'Incorrect password' });
      return;
    }
    try {
      await db.deleteOrders(ids);
      io.to(ROOM).emit('order:deleted', { ids });
      ack && ack({ ok: true });
    } catch (err) {
      console.error('order:delete-bulk failed', err);
      ack && ack({ ok: false, error: 'Failed to delete orders' });
    }
  });

  // ---- Expenses -------------------------------------------------------

  socket.on('expense:create', async (payload, ack) => {
    try {
      const expense = await db.createExpense(payload);
      io.to(ROOM).emit('expense:created', expense);
      ack && ack({ ok: true, expense });
    } catch (err) {
      console.error('expense:create failed', err);
      ack && ack({ ok: false, error: 'Failed to add expense' });
    }
  });

  socket.on('expense:delete', async ({ id, password }, ack) => {
    if (password !== DELETE_PASSWORD) {
      ack && ack({ ok: false, error: 'Incorrect password' });
      return;
    }
    try {
      await db.deleteExpense(id);
      io.to(ROOM).emit('expense:deleted', { id });
      ack && ack({ ok: true });
    } catch (err) {
      console.error('expense:delete failed', err);
      ack && ack({ ok: false, error: 'Failed to delete expense' });
    }
  });
});

// ---- REST: initial page load pulls full state once over HTTP -------
// (Sockets handle every update after this; this endpoint just avoids
// waiting on a round-trip handshake before the first render.)
app.get('/api/state', async (req, res) => {
  try {
    const [orders, expenses] = await Promise.all([db.getAllOrders(), db.getAllExpenses()]);
    res.json({ orders, expenses });
  } catch (err) {
    console.error('GET /api/state failed', err);
    res.status(500).json({ error: 'Failed to load state' });
  }
});

app.post('/api/login/delivery', (req, res) => {
  const { password } = req.body || {};
  res.json({ ok: password === DELIVERY_PASSWORD });
});

app.get('/health', (req, res) => res.json({ ok: true }));

db.init()
  .then(() => {
    server.listen(PORT, () => console.log(`Verta Delivery server listening on :${PORT}`));
  })
  .catch((err) => {
    console.error('Failed to initialize database', err);
    process.exit(1);
  });
